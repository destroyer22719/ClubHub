const token = localStorage.getItem("token");

if (token) {
    location.href="profile.html"
}