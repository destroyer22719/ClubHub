require("dotenv").config();
console.log(process.env.MONGODB_URL)
console.log("hello world")

